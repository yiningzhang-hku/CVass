chrome.runtime.onInstalled.addListener(() => {
  console.log('JobForm Autofill installed/updated');
});
